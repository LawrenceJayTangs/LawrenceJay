# Lawrence Jay Tangaro Portfolio

This is a simple portfolio website made with HTML and CSS.

## Files

- `index.html` - main website file
- `assets/images/profile-home.jpg` - home page profile picture
- `assets/images/about-me.jpg` - about me picture

## How to upload to GitHub

1. Create a new repository on GitHub.
2. Upload `index.html` and the `assets` folder.
3. Commit the files.
4. Go to Settings > Pages.
5. Under Branch, choose `main`.
6. Click Save.
7. Wait for GitHub Pages to give you your website link.
